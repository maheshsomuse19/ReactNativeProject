import AsyncStorage from '@react-native-async-storage/async-storage';

import {
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
  ActivityIndicator,
} from 'react-native';
import React, {useState, useContext} from 'react';
import {AuthContext} from '../context/AuthContext';
import {TextInput} from 'react-native-paper';

const LoginScreen = ({navigation}) => {
  const {login} = useContext(AuthContext);
  const {isLoading, userToken} = useContext(AuthContext);
  // const userInfo = {userName: 'admin', pass: 'pass123'};
  const [userName, setUserName] = useState('');
  const [pass, setPassword] = useState('');
  const [checkPassowrd, setCheckPassword] = useState(true);

  if (isLoading) {
    <View>
      <ActivityIndicator size={'large'}></ActivityIndicator>;
    </View>;
  }
  const onLogin = () => {
    navigation.navigate('Login');

    login();
  };

  return (
    <View>
      {userToken !== null ? (
        navigation.navigate('Home')
      ) : (
        <View style={{display: 'flex', justifyContent: 'center', top: 100}}>
          <View>
            <Text
              style={{
                color: 'black',

                fontSize: 20,
                marginHorizontal: 25,
                fontSize: 30,
              }}>
              Login
            </Text>
            {/* <Text style={{marginHorizontal: 25}}>{test}</Text> */}
          </View>

          <View>
            <TextInput
              placeholder="Enter Username"
              value={userName}
              onChangeText={text => setUserName(text)}
              style={{marginHorizontal: 25, marginTop: 20}}></TextInput>

            <TextInput
              value={pass}
              onChangeText={text => setPassword(text)}
              placeholder="Enter password"
              style={{marginHorizontal: 25, marginTop: 20}}></TextInput>
          </View>

          <View>
            <TouchableOpacity
              style={{
                backgroundColor: 'orange',
                marginHorizontal: 25,
                marginTop: 20,
                padding: 10,
              }}
              onPress={onLogin}>
              <Text style={{textAlign: 'center', color: 'white', fontSize: 20}}>
                Login
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      )}
    </View>
  );
};

export default LoginScreen;

const styles = StyleSheet.create({});
